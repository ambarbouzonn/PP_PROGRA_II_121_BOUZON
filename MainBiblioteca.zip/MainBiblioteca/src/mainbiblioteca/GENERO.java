package mainbiblioteca;

public enum GENERO {
    FICCION, NO_FICCION, CIENCIA, HISTORIA;
}
